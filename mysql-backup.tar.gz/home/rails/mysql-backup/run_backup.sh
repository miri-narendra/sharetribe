#!/bin/bash
find /home/rails/mysql-backup/dumps/ -type f -mtime +3 -exec rm {} +
mysqldump -u rails_production -pB9JnAgwHxRzx motorhome_production -h 127.0.0.1 > /home/rails/mysql-backup/dumps/$(date +%F)_motorhome_production.sql
